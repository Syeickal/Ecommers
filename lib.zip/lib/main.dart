import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool("loggedIn") ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi E-Commerce',
      debugShowCheckedModeBanner: false, // Sembunyikan banner debug
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.deepOrange,
        ).copyWith(
          secondary: Colors.amber, // Warna aksen
          background: Colors.grey[50], // Warna latar belakang umum
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white, // Bilah aplikasi seringkali putih atau terang
          foregroundColor: Colors.black87, // Warna teks untuk bilah aplikasi
          elevation: 1, // Bayangan halus
          centerTitle: true, // Judul di tengah
          titleTextStyle: TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.w600,
          ),
        ),
        textTheme: TextTheme(
          headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87), // Untuk judul besar
          titleMedium: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black87), // Untuk nama produk/judul sedang
          titleSmall: TextStyle(fontSize: 16, color: Colors.black54), // Untuk harga produk/subtitle
          bodyMedium: TextStyle(fontSize: 16, color: Colors.black54), // Untuk teks isi umum
          labelLarge: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.w500), // Untuk teks tombol
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.deepOrange, // Latar belakang tombol
            foregroundColor: Colors.white,      // Warna teks tombol
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), // Sudut tombol lebih membulat
            textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.deepOrange,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme( // Tema untuk TextField
          filled: true,
          fillColor: Colors.grey[100],
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Colors.deepOrange, width: 2),
          ),
          contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          hintStyle: TextStyle(color: Colors.grey[500]),
        ),
        // PERBAIKAN: Mengganti CardTheme dengan CardThemeData
        cardTheme: CardThemeData( // Menggunakan CardThemeData
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          margin: EdgeInsets.zero, // Default margin nol, atur di widget masing-masing
        ),
      ),
      home: FutureBuilder<bool>(
        future: isLoggedIn(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            // Tampilan loading kustom untuk pengalaman yang lebih baik
            return Scaffold(
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Pastikan Anda memiliki 'assets/logo.png' dan sudah dideklarasikan di pubspec.yaml
                    // Image.asset('assets/logo.png', width: 100, height: 100),
                    SizedBox(height: 20),
                    CircularProgressIndicator(color: Colors.deepOrange),
                    SizedBox(height: 10),
                    Text('Memuat...', style: Theme.of(context).textTheme.titleSmall),
                  ],
                ),
              ),
            );
          }
          return snapshot.data! ? HomeScreen() : LoginScreen();
        },
      ),
    );
  }
}