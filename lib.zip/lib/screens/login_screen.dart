import 'package:ecommerce_app/screens/register_screen.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatelessWidget {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final AuthService _auth = AuthService();

  void login(BuildContext context) async {
    print("Input Username: ${userCtrl.text}"); // Debug input
    print("Input Password: ${passCtrl.text}");

    final user = await _auth.login(userCtrl.text, passCtrl.text);
    if (user != null) {
      final prefs = await SharedPreferences.getInstance();
      prefs.setBool('loggedIn', true);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login sukses!')));
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen()));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login gagal')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: userCtrl,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            SizedBox(height: 8),
            TextField(
              controller: passCtrl,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => login(context),
              child: const Text('Login'),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
              ),
            ),
            SizedBox(height: 8),
            // Add this to the Column children list in login_screen.dart, after the ElevatedButton
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => RegisterScreen()),
                );
              },
              child: const Text('Don\'t have an account? Register'),
            ),
          ],
        ),
      ),
    );
  }
}
