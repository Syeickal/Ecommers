import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../models/product.dart';
import 'dart:convert';

// --- Model Sederhana untuk Jasa Pengiriman ---
class ShippingService {
  final String id;
  final String name;
  final double cost;
  final String description;

  ShippingService({
    required this.id,
    required this.name,
    required this.cost,
    this.description = '',
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ShippingService &&
        runtimeType == other.runtimeType &&
        id == other.id;
  }

  @override
  int get hashCode => id.hashCode;

  static List<ShippingService> get availableServices => [
    ShippingService(id: 'jne_reg', name: 'JNE Reguler', cost: 15000.0, description: '2-4 hari kerja'),
    ShippingService(id: 'pos_kilat', name: 'POS Kilat Khusus', cost: 18000.0, description: '1-3 hari kerja'),
    ShippingService(id: 'tiki_eco', name: 'TIKI Ekonomi', cost: 12000.0, description: '3-5 hari kerja'),
    ShippingService(id: 'gosend', name: 'GoSend Same Day', cost: 25000.0, description: 'Tiba di hari yang sama'),
  ];
}
// --- Akhir Model Sederhana untuk Jasa Pengiriman ---

class CartScreen extends StatefulWidget {
  final VoidCallback? onCartChanged;

  CartScreen({this.onCartChanged});

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<Product> cart = [];
  bool _isLoading = false;

  late ShippingService _selectedShippingService;

  @override
  void initState() {
    super.initState();
    if (ShippingService.availableServices.isNotEmpty) {
      _selectedShippingService = ShippingService.availableServices.first;
    } else {
      _selectedShippingService = ShippingService(id: 'none', name: 'Tidak Ada Pengiriman', cost: 0.0);
    }
    loadCart();
  }

  void loadCart() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      List<String> raw = prefs.getStringList('cart') ?? [];
      setState(() {
        cart = raw.map((item) => Product.fromJson(json.decode(item))).toList();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat keranjang: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void removeItem(Product productToRemove) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> rawCart = prefs.getStringList('cart') ?? [];

    List<Product> currentCart = rawCart.map((item) => Product.fromJson(json.decode(item))).toList();
    currentCart.removeWhere((p) => p.id == productToRemove.id);

    setState(() {
      cart = currentCart;
    });
    prefs.setStringList('cart', currentCart.map((p) => json.encode(p.toJson())).toList());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${productToRemove.name} dihapus dari keranjang')),
    );
    widget.onCartChanged?.call();
  }

  double get subtotal => cart.fold(0, (sum, item) => sum + item.price);
  double get grandTotal => subtotal + _selectedShippingService.cost;

  void checkout() async {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Keranjang Anda kosong! Silakan tambahkan produk.')));
      return;
    }

    if (_selectedShippingService.id == 'none' && ShippingService.availableServices.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Silakan pilih jasa pengiriman.')));
      return;
    }

    final bool? confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Konfirmasi Pembayaran'),
        content: Text('Anda akan membayar sebesar ${NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(grandTotal)} untuk pesanan ini, termasuk biaya pengiriman melalui ${_selectedShippingService.name}. Lanjutkan?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Bayar'),
            style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.primary),
          ),
        ],
      ),
    );

    if (confirm == true) {
      setState(() => _isLoading = true);

      await Future.delayed(Duration(seconds: 2));

      try {
        final prefs = await SharedPreferences.getInstance();
        prefs.remove('cart');

        setState(() {
          cart.clear();
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Pembayaran berhasil! Terima kasih telah berbelanja!')),
        );
        widget.onCartChanged?.call();
        Navigator.pop(context);

      } catch (e) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Terjadi kesalahan saat pembayaran: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    return Scaffold(
      appBar: AppBar(title: Text('Keranjang Belanja')),
      body: _isLoading && cart.isEmpty
          ? Center(child: CircularProgressIndicator(color: Colors.deepOrange))
          : cart.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_cart_outlined, size: 100, color: Colors.grey[400]),
            SizedBox(height: 16),
            Text(
              'Keranjang Anda kosong',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.grey[600]),
            ),
            SizedBox(height: 8),
            Text(
              'Ayo temukan produk favorit Anda!',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[500]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.store),
              label: Text('Belanja Sekarang'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      )
          : Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cart.length,
              itemBuilder: (_, i) {
                final p = cart[i];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            p.image,
                            width: 80,
                            height: 80,
                            fit: BoxFit.cover,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Center(child: CircularProgressIndicator(
                                value: loadingProgress.expectedTotalBytes != null
                                    ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                                    : null,
                                color: Colors.deepOrange,
                                strokeWidth: 2,
                              ));
                            },
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                                  width: 80,
                                  height: 80,
                                  color: Colors.grey[200],
                                  child: Icon(Icons.broken_image, size: 40, color: Colors.grey[400]),
                                ),
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 4),
                              Text(
                                currencyFormatter.format(p.price),
                                style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Theme.of(context).colorScheme.primary),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete_outline, color: Colors.redAccent, size: 28),
                          onPressed: () => removeItem(p),
                          tooltip: 'Hapus dari Keranjang',
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: Offset(0, -5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Pilih Jasa Pengiriman:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                // PERBAIKAN: Mengganti improper cast dengan BoxDecoration langsung
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<ShippingService>(
                      isExpanded: true,
                      value: _selectedShippingService,
                      icon: const Icon(Icons.arrow_drop_down, color: Colors.grey),
                      iconSize: 24,
                      elevation: 2,
                      style: Theme.of(context).textTheme.bodyMedium,
                      onChanged: (ShippingService? newValue) {
                        setState(() {
                          if (newValue != null) {
                            _selectedShippingService = newValue;
                          }
                        });
                      },
                      items: ShippingService.availableServices
                          .map<DropdownMenuItem<ShippingService>>((ShippingService service) {
                        return DropdownMenuItem<ShippingService>(
                          value: service,
                          child: Text(
                            '${service.name} (${service.description}) - ${currencyFormatter.format(service.cost)}',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  'Ringkasan Pesanan:',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                _buildSummaryRow(
                  context,
                  'Subtotal Produk:',
                  currencyFormatter.format(subtotal),
                ),
                SizedBox(height: 8),
                _buildSummaryRow(
                  context,
                  'Biaya Pengiriman:',
                  currencyFormatter.format(_selectedShippingService.cost),
                ),
                Divider(height: 30, thickness: 1.5, color: Colors.grey[400]),
                _buildSummaryRow(
                  context,
                  'Total Pembayaran:',
                  currencyFormatter.format(grandTotal),
                  isTotal: true,
                ),
                SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _isLoading || cart.isEmpty || ShippingService.availableServices.isEmpty ? null : checkout,
                  style: Theme.of(context).elevatedButtonTheme.style?.copyWith(
                    padding: MaterialStateProperty.all(EdgeInsets.symmetric(vertical: 14)),
                  ),
                  child: _isLoading
                      ? SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Text('Bayar Sekarang', style: Theme.of(context).textTheme.labelLarge),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildSummaryRow(BuildContext context, String label, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: isTotal
              ? Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)
              : Theme.of(context).textTheme.bodyMedium,
        ),
        Text(
          value,
          style: isTotal
              ? Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: Theme.of(context).colorScheme.primary,
            fontWeight: FontWeight.bold,
          )
              : Theme.of(context).textTheme.titleSmall,
        ),
      ],
    );
  }
}