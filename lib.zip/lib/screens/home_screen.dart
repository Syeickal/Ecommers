import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/product_service.dart';
import '../models/product.dart';
import 'cart_screen.dart';
import 'login_screen.dart'; // Impor layar login
import '../widgets/product_card.dart';
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Product> products = [];
  List<Product> filteredProducts = [];
  TextEditingController searchController = TextEditingController();
  bool _isLoading = true; // Untuk mengelola status pemuatan awal produk
  int _cartItemCount = 0; // Untuk menampilkan jumlah item keranjang

  @override
  void initState() {
    super.initState();
    _loadInitialData();
    searchController.addListener(() {
      filterProducts(searchController.text);
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> _loadInitialData() async {
    await loadProducts();
    _updateCartItemCount(); // Pastikan jumlah keranjang diperbarui saat aplikasi dimulai
  }

  Future<void> loadProducts() async {
    setState(() => _isLoading = true);
    final service = ProductService();
    try {
      final data = await service.fetchProducts();
      setState(() {
        products = data;
        filteredProducts = data;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat produk: ${e.toString()}')),
      );
    }
  }

  void filterProducts(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredProducts = products;
      } else {
        filteredProducts = products.where((product) {
          final nameLower = product.name.toLowerCase();
          final searchLower = query.toLowerCase();
          return nameLower.contains(searchLower);
        }).toList();
      }
    });
  }

  void _updateCartItemCount() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> cart = prefs.getStringList('cart') ?? [];
    setState(() {
      _cartItemCount = cart.length;
    });
  }

  void addToCart(Product product) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> cart = prefs.getStringList('cart') ?? [];
    cart.add(json.encode(product.toJson()));
    prefs.setStringList('cart', cart);
    _updateCartItemCount(); // Perbarui jumlah keranjang segera
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product.name} ditambahkan ke keranjang'),
        action: SnackBarAction(
          label: 'Lihat Keranjang',
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => CartScreen(onCartChanged: _updateCartItemCount))).then((_) => _updateCartItemCount());
          },
        ),
        duration: Duration(seconds: 2), // Durasi snackbar
      ),
    );
  }

  void _logout() async {
    final prefs = await SharedPreferences.getInstance();
    // Tampilkan dialog konfirmasi logout
    final bool? confirmLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Konfirmasi Logout'),
        content: Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Keluar'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );

    if (confirmLogout == true) {
      await prefs.setBool('loggedIn', false); // Hapus status login
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Katalog Produk'),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => CartScreen(onCartChanged: _updateCartItemCount)),
                  ).then((_) => _updateCartItemCount()); // Segarkan jumlah keranjang saat kembali
                },
                tooltip: 'Keranjang Belanja',
              ),
              if (_cartItemCount > 0) // Tampilkan lencana hanya jika ada item
                Positioned(
                  right: 5,
                  top: 5,
                  child: Container(
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      '$_cartItemCount',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
            ],
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0), // Padding yang diperbesar
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Cari produk...',
                prefixIcon: Icon(Icons.search),
                suffixIcon: searchController.text.isNotEmpty
                    ? IconButton(
                  icon: Icon(Icons.clear, color: Colors.grey[600]),
                  onPressed: () => searchController.clear(),
                )
                    : null,
                // Gaya input decoration sudah diatur di tema utama
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator(color: Colors.deepOrange)) // Indikator loading produk
                : RefreshIndicator( // Tambahkan tarik untuk menyegarkan
              onRefresh: loadProducts,
              color: Colors.deepOrange,
              child: filteredProducts.isEmpty
                  ? SingleChildScrollView( // Tambahkan SingleChildScrollView agar RefreshIndicator berfungsi pada daftar kosong
                physics: AlwaysScrollableScrollPhysics(), // Selalu bisa digulir
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.6, // Agar Center bekerja dengan baik
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.sentiment_dissatisfied, size: 100, color: Colors.grey[400]),
                        SizedBox(height: 16),
                        Text(
                          searchController.text.isEmpty
                              ? 'Belum ada produk untuk saat ini.'
                              : 'Tidak ada produk yang cocok dengan pencarian Anda.',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.grey[600]),
                        ),
                        if (searchController.text.isNotEmpty) ...[
                          SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: () => searchController.clear(),
                            child: Text('Hapus Pencarian'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueGrey, // Warna tombol berbeda
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              )
                  : ListView.builder(
                itemCount: filteredProducts.length,
                itemBuilder: (_, i) => ProductCard(
                  product: filteredProducts[i],
                  onAdd: () => addToCart(filteredProducts[i]),
                  // Anda bisa menambahkan onTap untuk navigasi ke detail produk di sini
                  // onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: filteredProducts[i]))),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}