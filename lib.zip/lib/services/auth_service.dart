import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import '../models/user.dart';

// PERBAIKAN: Enum AuthResult dipindahkan keluar dari class AuthService
enum AuthResult { success, invalidCredentials, networkError, unknownError }

class AuthService {
  final String baseUrl = 'http://localhost:3000';

  String _hashPassword(String password) {
    var bytes = utf8.encode(password);
    var digest = sha256.convert(bytes);
    return digest.toString();
  }

  Future<AuthResult> login(String username, String password) async {
    try {
      final hashedPassword = _hashPassword(password);
      final url = Uri.parse('$baseUrl/users?username=$username&password=$hashedPassword');
      final res = await http.get(url);

      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        if (data.isNotEmpty) {
          // Asumsi login berhasil jika ada data pengguna yang cocok
          return AuthResult.success;
        } else {
          return AuthResult.invalidCredentials;
        }
      } else {
        // Handle status code lainnya
        return AuthResult.unknownError;
      }
    } catch (e) {
      // Tangani error jaringan
      return AuthResult.networkError;
    }
  }

  // Untuk register, Anda bisa mengembalikan User? atau AuthResult juga
  Future<User?> register(String username, String password, String fullName) async {
    try {
      final hashedPassword = _hashPassword(password);
      final url = Uri.parse('$baseUrl/users');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'username': username,
          'password': hashedPassword,
          'fullName': fullName,
          'id': DateTime.now().millisecondsSinceEpoch.toString(), // ID unik sederhana
        }),
      );

      if (res.statusCode == 201) { // 201 Created
        final data = json.decode(res.body);
        return User.fromJson(data);
      }
      return null;
    } catch (e) {
      print('Error during registration: $e');
      return null;
    }
  }
}