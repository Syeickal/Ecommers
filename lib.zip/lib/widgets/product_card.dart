import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Impor untuk pemformatan angka
import '../models/product.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;
  final VoidCallback? onTap; // Opsional untuk menuju detail produk

  ProductCard({required this.product, required this.onAdd, this.onTap});

  @override
  Widget build(BuildContext context) {
    // Gunakan NumberFormat untuk harga Rupiah
    final currencyFormatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ', // Simbol rupiah
      decimalDigits: 0, // Tanpa desimal untuk rupiah
    );

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8), // Margin yang lebih seimbang
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2, // Elevasi sedikit lebih rendah untuk tampilan modern
      child: InkWell( // Jadikan kartu bisa disentuh (untuk detail produk)
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center, // Sejajarkan item secara vertikal
            children: [
              // Gambar produk dengan sudut membulat dan placeholder loading/error
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  product.image,
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded / loadingProgress.expectedTotalBytes!
                            : null,
                        color: Colors.deepOrange,
                        strokeWidth: 2,
                      ),
                    );
                  },
                  errorBuilder: (context, error, stackTrace) =>
                      Container(
                        width: 80,
                        height: 80,
                        color: Colors.grey[200],
                        child: Icon(Icons.broken_image, size: 40, color: Colors.grey[400]),
                      ),
                ),
              ),
              SizedBox(width: 16),
              // Detail nama dan harga produk
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold), // Gunakan tema
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4),
                    Text(
                      currencyFormatter.format(product.price), // Harga terformat
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ), // Gunakan tema
                    ),
                  ],
                ),
              ),
              SizedBox(width: 12), // Spasi sebelum tombol
              // Tombol 'Tambah ke Keranjang'
              ElevatedButton.icon(
                onPressed: onAdd,
                icon: Icon(Icons.add_shopping_cart, size: 18), // Ikon yang lebih spesifik
                label: Text('Tambah'), // Label yang lebih jelas
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(80, 40), // Berikan ukuran minimum
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8), // Padding tombol
                  textStyle: Theme.of(context).textTheme.labelLarge?.copyWith(fontSize: 14),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}